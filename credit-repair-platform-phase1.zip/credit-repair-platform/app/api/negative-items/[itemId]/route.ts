import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/db";
import { requireRole, requireClientAccess, ForbiddenError, UnauthenticatedError } from "@/lib/auth/rbac";
import { logClientActivity, writeAuditLog } from "@/lib/audit";

// Whitelist state machine (ARCHITECTURE.md § G) — prevents a status
// jump that skips required steps (e.g. IDENTIFIED straight to DELETED).
const ALLOWED_TRANSITIONS: Record<string, string[]> = {
  IDENTIFIED: ["RESEARCHING", "CLOSED"],
  RESEARCHING: ["ELIGIBLE_FOR_DISPUTE", "DOCUMENTATION_NEEDED", "CLOSED"],
  DOCUMENTATION_NEEDED: ["ELIGIBLE_FOR_DISPUTE", "CLOSED"],
  ELIGIBLE_FOR_DISPUTE: ["READY", "CLOSED"],
  READY: ["SENT"],
  SENT: ["PENDING"],
  PENDING: ["VERIFIED", "UPDATED", "DELETED", "CORRECTED", "ESCALATED"],
  VERIFIED: ["ESCALATED", "READY", "CLOSED"], // eligible for next round
  UPDATED: ["CLOSED", "READY"],
  ESCALATED: ["CLOSED", "READY"],
  DELETED: ["CLOSED"],
  CORRECTED: ["CLOSED"],
  CLOSED: [],
};

const updateSchema = z.object({
  status: z.string(),
  bureauResponse: z.string().optional(),
  furnisherResponse: z.string().optional(),
  result: z.string().optional(),
});

export async function PATCH(req: NextRequest, { params }: { params: { itemId: string } }) {
  try {
    const session = await requireRole(["SUPER_ADMIN", "CREDIT_SPECIALIST", "COMPLIANCE_ADMIN"]);

    const item = await prisma.negativeItem.findUnique({ where: { id: params.itemId } });
    if (!item) return NextResponse.json({ error: "Not found" }, { status: 404 });

    await requireClientAccess(item.clientId);

    const body = await req.json();
    const parsed = updateSchema.safeParse(body);
    if (!parsed.success) {
      return NextResponse.json({ error: parsed.error.flatten() }, { status: 400 });
    }

    const allowedNext = ALLOWED_TRANSITIONS[item.status] ?? [];
    if (!allowedNext.includes(parsed.data.status)) {
      return NextResponse.json(
        { error: `Cannot move from ${item.status} to ${parsed.data.status}. Allowed: ${allowedNext.join(", ") || "none"}` },
        { status: 400 }
      );
    }

    const data: any = { status: parsed.data.status };
    if (parsed.data.bureauResponse) data.bureauResponse = parsed.data.bureauResponse;
    if (parsed.data.furnisherResponse) data.furnisherResponse = parsed.data.furnisherResponse;
    if (parsed.data.result) data.result = parsed.data.result;
    if (parsed.data.status === "DELETED") data.deletedDate = new Date();
    if (parsed.data.status === "CORRECTED") data.correctedDate = new Date();

    const updated = await prisma.negativeItem.update({ where: { id: params.itemId }, data });

    const actorId = (session.user as any).id;

    await logClientActivity({
      clientId: item.clientId,
      actorId,
      actorType: "user",
      description: `Negative item ${item.category.replaceAll("_", " ")}: ${item.status} → ${parsed.data.status}`,
    });

    await writeAuditLog({
      actorId,
      action: "NEGATIVE_ITEM_STATUS_CHANGED",
      entityType: "NegativeItem",
      entityId: item.id,
      previousValue: { status: item.status },
      newValue: { status: parsed.data.status },
    });

    return NextResponse.json({ item: updated });
  } catch (err) {
    return handleError(err);
  }
}

function handleError(err: unknown) {
  if (err instanceof UnauthenticatedError) return NextResponse.json({ error: "Not authenticated" }, { status: 401 });
  if (err instanceof ForbiddenError) return NextResponse.json({ error: err.message }, { status: 403 });
  console.error(err);
  return NextResponse.json({ error: "Internal error" }, { status: 500 });
}
