import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import bcrypt from "bcryptjs";
import { prisma } from "@/lib/db";
import { writeAuditLog } from "@/lib/audit";

const setupSchema = z.object({
  email: z.string().email(),
  password: z.string().min(10, "Password must be at least 10 characters"),
});

// This route intentionally requires NO authentication — it's how the
// very first admin account gets created on a fresh deploy with no
// terminal access. It self-closes permanently the moment any user
// exists, so it cannot be used to create a second admin or by anyone
// after the real admin has set up their account.
export async function GET() {
  const existingUsers = await prisma.user.count();
  return NextResponse.json({ setupNeeded: existingUsers === 0 });
}

export async function POST(req: NextRequest) {
  const existingUsers = await prisma.user.count();
  if (existingUsers > 0) {
    return NextResponse.json(
      { error: "Setup has already been completed. Log in normally, or ask an existing SUPER_ADMIN to create your account." },
      { status: 403 }
    );
  }

  const body = await req.json();
  const parsed = setupSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ error: parsed.error.flatten() }, { status: 400 });
  }

  const passwordHash = await bcrypt.hash(parsed.data.password, 12);

  const user = await prisma.user.create({
    data: {
      email: parsed.data.email.toLowerCase(),
      passwordHash,
      role: "SUPER_ADMIN",
      isActive: true,
    },
  });

  await writeAuditLog({
    actorId: user.id,
    action: "INITIAL_SETUP_COMPLETED",
    entityType: "User",
    entityId: user.id,
  });

  return NextResponse.json({ success: true });
}
