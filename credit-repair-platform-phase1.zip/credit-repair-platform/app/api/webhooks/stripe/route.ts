import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/db";
import { stripe } from "@/lib/payments/stripe";
import { logClientActivity, writeAuditLog } from "@/lib/audit";
import Stripe from "stripe";

// This is the ONLY place a payment is marked PAID as a result of an
// actual card charge — never the success_url redirect, which a user
// could hit without ever paying (back button, shared link, etc.).
// Signature verification is what makes this trustworthy.
export async function POST(req: NextRequest) {
  const body = await req.text();
  const signature = req.headers.get("stripe-signature");

  if (!signature || !process.env.STRIPE_WEBHOOK_SECRET) {
    return NextResponse.json({ error: "Missing signature or webhook secret not configured" }, { status: 400 });
  }

  let event: Stripe.Event;
  try {
    event = stripe.webhooks.constructEvent(body, signature, process.env.STRIPE_WEBHOOK_SECRET);
  } catch (err: any) {
    console.error("Stripe webhook signature verification failed:", err.message);
    return NextResponse.json({ error: "Invalid signature" }, { status: 400 });
  }

  if (event.type === "checkout.session.completed") {
    const session = event.data.object as Stripe.Checkout.Session;
    const paymentId = session.metadata?.paymentId;

    if (paymentId) {
      const payment = await prisma.payment.findUnique({ where: { id: paymentId } });
      if (payment && payment.status !== "PAID") {
        await prisma.payment.update({
          where: { id: paymentId },
          data: {
            status: "PAID",
            paidDate: new Date(),
            stripePaymentIntentId: typeof session.payment_intent === "string" ? session.payment_intent : undefined,
            method: "Card (Stripe)",
          },
        });

        await logClientActivity({
          clientId: payment.clientId,
          actorId: null,
          actorType: "automation",
          description: `Payment received via Stripe: ${payment.invoiceLabel ?? "Charge"} — $${payment.amount}`,
        });

        await writeAuditLog({
          actorId: null,
          action: "PAYMENT_CONFIRMED_STRIPE",
          entityType: "Payment",
          entityId: paymentId,
          newValue: { stripeSessionId: session.id },
        });
      }
    }
  }

  // Card declined / checkout expired — surface it rather than leaving
  // the charge silently stuck in UNPAID with no explanation.
  if (event.type === "checkout.session.expired") {
    const session = event.data.object as Stripe.Checkout.Session;
    const paymentId = session.metadata?.paymentId;
    if (paymentId) {
      await writeAuditLog({
        actorId: null,
        action: "PAYMENT_CHECKOUT_EXPIRED",
        entityType: "Payment",
        entityId: paymentId,
      });
    }
  }

  return NextResponse.json({ received: true });
}
