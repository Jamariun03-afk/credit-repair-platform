import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/db";
import { requireRole, requireClientAccess, ForbiddenError, UnauthenticatedError } from "@/lib/auth/rbac";
import { logClientActivity, writeAuditLog } from "@/lib/audit";

const schema = z.object({
  summary: z.string().min(1),
  responseDate: z.string().datetime(),
  fileKey: z.string().optional(), // uploaded separately via the document vault, referenced here
});

// POST /api/dispute-rounds/[roundId]/bureau-response
// Records the bureau's response (spec MVP step 13). Does NOT
// automatically change individual item statuses — the specialist
// still reviews each item and moves it via PATCH /api/negative-items/[id],
// since one bureau letter can come back with different outcomes per
// account and the system should never guess which happened to which.
export async function POST(req: NextRequest, { params }: { params: { roundId: string } }) {
  try {
    const session = await requireRole(["SUPER_ADMIN", "CREDIT_SPECIALIST", "COMPLIANCE_ADMIN"]);

    const round = await prisma.disputeRound.findUnique({
      where: { id: params.roundId },
      include: { dispute: true },
    });
    if (!round) return NextResponse.json({ error: "Not found" }, { status: 404 });

    await requireClientAccess(round.dispute.clientId);

    const body = await req.json();
    const parsed = schema.safeParse(body);
    if (!parsed.success) {
      return NextResponse.json({ error: parsed.error.flatten() }, { status: 400 });
    }

    const [response] = await prisma.$transaction([
      prisma.bureauResponse.create({
        data: {
          disputeRoundId: round.id,
          bureau: round.dispute.bureau,
          responseDate: new Date(parsed.data.responseDate),
          summary: parsed.data.summary,
          fileKey: parsed.data.fileKey,
        },
      }),
      prisma.disputeRound.update({
        where: { id: round.id },
        data: { bureauResponse: parsed.data.summary },
      }),
    ]);

    const actorId = (session.user as any).id;

    await logClientActivity({
      clientId: round.dispute.clientId,
      actorId,
      actorType: "user",
      description: `${round.dispute.bureau} response received for Round ${round.roundNumber}: ${parsed.data.summary}`,
    });

    await writeAuditLog({
      actorId,
      action: "BUREAU_RESPONSE_RECORDED",
      entityType: "BureauResponse",
      entityId: response.id,
      newValue: { roundId: round.id },
    });

    // Hook point for the BUREAU_RESPONSE_UPLOADED automation trigger
    // (§15) — e.g. auto-create a "review response" task per item.

    return NextResponse.json({ response }, { status: 201 });
  } catch (err) {
    return handleError(err);
  }
}

function handleError(err: unknown) {
  if (err instanceof UnauthenticatedError) return NextResponse.json({ error: "Not authenticated" }, { status: 401 });
  if (err instanceof ForbiddenError) return NextResponse.json({ error: err.message }, { status: 403 });
  console.error(err);
  return NextResponse.json({ error: "Internal error" }, { status: 500 });
}
