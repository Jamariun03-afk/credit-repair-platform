import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/db";
import { requireRole, requireClientAccess, ForbiddenError, UnauthenticatedError } from "@/lib/auth/rbac";
import { logClientActivity, writeAuditLog } from "@/lib/audit";
import { renderTemplate, BUREAU_ADDRESSES } from "@/lib/pdf/renderTemplate";
import { textToPdf } from "@/lib/pdf/generateLetterPdf";
import { buildStorageKey, uploadBuffer } from "@/lib/storage/s3";

const generateSchema = z.object({
  letterType: z.enum([
    "EXPERIAN_DISPUTE", "EQUIFAX_DISPUTE", "TRANSUNION_DISPUTE", "FURNISHER_DIRECT_DISPUTE",
    "IDENTITY_THEFT_BLOCK_REQUEST", "PERSONAL_INFO_CORRECTION", "INQUIRY_DISPUTE",
    "REINVESTIGATION_REQUEST", "METHOD_OF_VERIFICATION_REQUEST", "REINSERTION_DISPUTE",
    "FOLLOW_UP", "CFPB_ESCALATION", "GENERAL_CORRESPONDENCE",
  ]),
  requestedAction: z.string().min(1),
});

// POST /api/dispute-rounds/[roundId]/letters
// Generates one letter covering every item in the round (grouped per
// bureau letter — a single letter can list multiple accounts).
export async function POST(req: NextRequest, { params }: { params: { roundId: string } }) {
  try {
    const session = await requireRole(["SUPER_ADMIN", "CREDIT_SPECIALIST"]);

    const round = await prisma.disputeRound.findUnique({
      where: { id: params.roundId },
      include: {
        dispute: { include: { client: { include: { addresses: true } } } },
        items: { include: { negativeItem: { include: { tradelines: { include: { tradeline: true } } } } } },
      },
    });
    if (!round) return NextResponse.json({ error: "Round not found" }, { status: 404 });

    await requireClientAccess(round.dispute.clientId);

    if (round.sentDate) {
      return NextResponse.json({ error: "This round has already been sent — generate a new round instead of editing a sent one" }, { status: 400 });
    }
    if (round.items.length === 0) {
      return NextResponse.json({ error: "Round has no items" }, { status: 400 });
    }

    const body = await req.json();
    const parsed = generateSchema.safeParse(body);
    if (!parsed.success) {
      return NextResponse.json({ error: parsed.error.flatten() }, { status: 400 });
    }

    const template = await prisma.templateDocument.findFirst({
      where: { letterType: parsed.data.letterType, isActive: true },
      orderBy: { updatedAt: "desc" },
    });
    if (!template) {
      return NextResponse.json({ error: `No active template configured for ${parsed.data.letterType}` }, { status: 400 });
    }

    const client = round.dispute.client;
    const bureauInfo = BUREAU_ADDRESSES[round.dispute.bureau];

    const currentAddress = client.addresses.find((a) => a.isCurrent) ?? client.addresses[0];
    if (!currentAddress) {
      return NextResponse.json(
        { error: "Client has no address on file — add one before generating a dispute letter" },
        { status: 400 }
      );
    }
    const clientAddressText = `${currentAddress.line1}${currentAddress.line2 ? ", " + currentAddress.line2 : ""}, ${currentAddress.city}, ${currentAddress.state} ${currentAddress.zip}`;

    const accountLines = round.items.map((item) => {
      const tradeline = item.negativeItem.tradelines[0]?.tradeline;
      return `- ${tradeline?.creditorName ?? item.negativeItem.furnisherName ?? "Account"} (${tradeline?.accountNumberMasked ?? "N/A"}): ${item.reasonType.replaceAll("_", " ")}`;
    }).join("\n");

    const supportingFacts = round.items
      .map((i) => i.supportingFacts)
      .filter(Boolean)
      .join("\n") || "See enclosed supporting documentation.";

    let rendered: string;
    try {
      rendered = renderTemplate(template.bodyTemplate, {
        client_name: `${client.firstName} ${client.lastName}`,
        client_address: clientAddressText,
        date: new Date().toLocaleDateString("en-US", { year: "numeric", month: "long", day: "numeric" }),
        bureau_name: bureauInfo?.name ?? round.dispute.bureau,
        bureau_address: bureauInfo?.address ?? "",
        account_name: accountLines,
        account_number: round.items.map((i) => i.negativeItem.tradelines[0]?.tradeline?.accountNumberMasked ?? "N/A").join(", "),
        dispute_reason: [...new Set(round.items.map((i) => i.reasonType.replaceAll("_", " ")))].join("; "),
        supporting_facts: supportingFacts,
        requested_action: parsed.data.requestedAction,
      });
    } catch (e: any) {
      return NextResponse.json({ error: e.message }, { status: 400 });
    }

    const pdfBuffer = await textToPdf(rendered, `${parsed.data.letterType} — ${client.lastName}`);
    const storageKey = buildStorageKey(client.id, "dispute_letter", `${parsed.data.letterType}-round${round.roundNumber}.pdf`);
    await uploadBuffer(storageKey, pdfBuffer, "application/pdf");

    const priorVersions = await prisma.disputeLetter.count({
      where: { disputeRoundId: round.id, letterType: parsed.data.letterType },
    });

    const letter = await prisma.disputeLetter.create({
      data: {
        disputeRoundId: round.id,
        letterType: parsed.data.letterType,
        templateId: template.id,
        version: priorVersions + 1,
        fileKey: storageKey,
      },
    });

    const actorId = (session.user as any).id;

    await logClientActivity({
      clientId: client.id,
      actorId,
      actorType: "user",
      description: `Round ${round.roundNumber} ${round.dispute.bureau} dispute letter generated (v${letter.version})`,
    });

    await writeAuditLog({
      actorId,
      action: "DISPUTE_LETTER_GENERATED",
      entityType: "DisputeLetter",
      entityId: letter.id,
      newValue: { letterType: letter.letterType, roundId: round.id },
    });

    return NextResponse.json({ letter }, { status: 201 });
  } catch (err) {
    return handleError(err);
  }
}

function handleError(err: unknown) {
  if (err instanceof UnauthenticatedError) return NextResponse.json({ error: "Not authenticated" }, { status: 401 });
  if (err instanceof ForbiddenError) return NextResponse.json({ error: err.message }, { status: 403 });
  console.error(err);
  return NextResponse.json({ error: "Internal error" }, { status: 500 });
}
