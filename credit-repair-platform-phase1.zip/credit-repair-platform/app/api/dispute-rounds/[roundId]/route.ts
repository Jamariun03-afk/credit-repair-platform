import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/db";
import { requireRole, requireClientAccess, ForbiddenError, UnauthenticatedError } from "@/lib/auth/rbac";
import { logClientActivity, writeAuditLog } from "@/lib/audit";

const DEFAULT_RESPONSE_WINDOW_DAYS = 30; // FCRA §611 baseline; configurable per spec §14, not hardcoded as a legal conclusion

const markMailedSchema = z.object({
  packageId: z.string().uuid(),
  mailProvider: z.string().optional(),
  certifiedMailNumber: z.string().optional(),
  trackingNumber: z.string().optional(),
  responseWindowDays: z.number().int().positive().default(DEFAULT_RESPONSE_WINDOW_DAYS),
});

export async function GET(_req: NextRequest, { params }: { params: { roundId: string } }) {
  try {
    const round = await prisma.disputeRound.findUnique({
      where: { id: params.roundId },
      include: {
        dispute: true,
        items: { include: { negativeItem: true } },
        letters: true,
        packages: true,
        bureauResponses: true,
      },
    });
    if (!round) return NextResponse.json({ error: "Not found" }, { status: 404 });

    await requireClientAccess(round.dispute.clientId);

    return NextResponse.json({ round });
  } catch (err) {
    return handleError(err);
  }
}

// PATCH — marks the package mailed, starts the deadline tracker, and
// moves every item in the round from READY to SENT (then the bureau
// response endpoint moves them to PENDING/VERIFIED/DELETED/etc).
// This is the natural DISPUTE_MAILED automation trigger hook (§15).
export async function PATCH(req: NextRequest, { params }: { params: { roundId: string } }) {
  try {
    const session = await requireRole(["SUPER_ADMIN", "CREDIT_SPECIALIST"]);

    const round = await prisma.disputeRound.findUnique({
      where: { id: params.roundId },
      include: { dispute: true, items: true, packages: true },
    });
    if (!round) return NextResponse.json({ error: "Not found" }, { status: 404 });

    await requireClientAccess(round.dispute.clientId);

    if (round.sentDate) {
      return NextResponse.json({ error: "Round already marked mailed" }, { status: 400 });
    }

    const body = await req.json();
    const parsed = markMailedSchema.safeParse(body);
    if (!parsed.success) {
      return NextResponse.json({ error: parsed.error.flatten() }, { status: 400 });
    }

    const pkg = round.packages.find((p) => p.id === parsed.data.packageId);
    if (!pkg) return NextResponse.json({ error: "Package not found on this round" }, { status: 400 });

    const sentDate = new Date();
    const responseDeadline = new Date(sentDate.getTime() + parsed.data.responseWindowDays * 24 * 60 * 60 * 1000);

    await prisma.$transaction([
      prisma.disputeRound.update({
        where: { id: round.id },
        data: { sentDate, responseDeadline },
      }),
      prisma.disputePackage.update({
        where: { id: pkg.id },
        data: {
          mailedDate: sentDate,
          mailProvider: parsed.data.mailProvider,
          certifiedMailNumber: parsed.data.certifiedMailNumber,
          trackingNumber: parsed.data.trackingNumber,
        },
      }),
      prisma.negativeItem.updateMany({
        where: { id: { in: round.items.map((i) => i.negativeItemId) } },
        data: { status: "SENT", mostRecentDisputeDate: sentDate },
      }),
    ]);

    const actorId = (session.user as any).id;

    await logClientActivity({
      clientId: round.dispute.clientId,
      actorId,
      actorType: "user",
      description: `Round ${round.roundNumber} mailed${parsed.data.certifiedMailNumber ? ` (certified #${parsed.data.certifiedMailNumber})` : ""} — response due ${responseDeadline.toLocaleDateString()}`,
    });

    await writeAuditLog({
      actorId,
      action: "DISPUTE_ROUND_MAILED",
      entityType: "DisputeRound",
      entityId: round.id,
      newValue: { sentDate, responseDeadline },
    });

    return NextResponse.json({ sentDate, responseDeadline });
  } catch (err) {
    return handleError(err);
  }
}

function handleError(err: unknown) {
  if (err instanceof UnauthenticatedError) return NextResponse.json({ error: "Not authenticated" }, { status: 401 });
  if (err instanceof ForbiddenError) return NextResponse.json({ error: err.message }, { status: 403 });
  console.error(err);
  return NextResponse.json({ error: "Internal error" }, { status: 500 });
}
