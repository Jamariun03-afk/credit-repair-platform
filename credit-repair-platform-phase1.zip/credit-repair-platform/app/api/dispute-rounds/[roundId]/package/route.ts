import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/db";
import { requireRole, requireClientAccess, ForbiddenError, UnauthenticatedError } from "@/lib/auth/rbac";
import { logClientActivity, writeAuditLog } from "@/lib/audit";
import { mergePdfs } from "@/lib/pdf/generateLetterPdf";
import { buildStorageKey, uploadBuffer } from "@/lib/storage/s3";
import { S3Client, GetObjectCommand } from "@aws-sdk/client-s3";

const s3 = new S3Client({
  region: process.env.S3_REGION,
  endpoint: process.env.S3_ENDPOINT || undefined,
  credentials: {
    accessKeyId: process.env.S3_ACCESS_KEY_ID ?? "",
    secretAccessKey: process.env.S3_SECRET_ACCESS_KEY ?? "",
  },
});

async function fetchObjectBuffer(key: string): Promise<Buffer> {
  const res = await s3.send(new GetObjectCommand({ Bucket: process.env.S3_BUCKET, Key: key }));
  const chunks: Uint8Array[] = [];
  // @ts-ignore - Body is a stream in Node runtime
  for await (const chunk of res.Body) chunks.push(chunk);
  return Buffer.concat(chunks);
}

const buildSchema = z.object({
  letterId: z.string().uuid(),
  documentIds: z.array(z.string().uuid()).default([]), // only PDF documents — see note below
});

// POST /api/dispute-rounds/[roundId]/package
// Compiles: cover letter + selected supporting PDF documents into one
// package PDF. Non-PDF documents (JPG/PNG scans) are not auto-converted
// here — flagged as a known follow-up rather than silently skipped.
export async function POST(req: NextRequest, { params }: { params: { roundId: string } }) {
  try {
    const session = await requireRole(["SUPER_ADMIN", "CREDIT_SPECIALIST"]);

    const round = await prisma.disputeRound.findUnique({
      where: { id: params.roundId },
      include: { dispute: true, letters: true },
    });
    if (!round) return NextResponse.json({ error: "Round not found" }, { status: 404 });

    await requireClientAccess(round.dispute.clientId);

    const body = await req.json();
    const parsed = buildSchema.safeParse(body);
    if (!parsed.success) {
      return NextResponse.json({ error: parsed.error.flatten() }, { status: 400 });
    }

    const letter = round.letters.find((l) => l.id === parsed.data.letterId);
    if (!letter || !letter.fileKey) {
      return NextResponse.json({ error: "Letter not found on this round" }, { status: 400 });
    }

    const documents = await prisma.clientDocument.findMany({
      where: { id: { in: parsed.data.documentIds }, clientId: round.dispute.clientId },
    });
    const nonPdf = documents.filter((d) => d.mimeType !== "application/pdf");
    if (nonPdf.length > 0) {
      return NextResponse.json({
        error: `These documents aren't PDFs and can't be auto-merged yet: ${nonPdf.map((d) => d.fileName).join(", ")}. Convert to PDF and re-attach, or mail them alongside the package separately.`,
      }, { status: 400 });
    }

    const letterBuffer = await fetchObjectBuffer(letter.fileKey);
    const docBuffers = await Promise.all(documents.map((d) => fetchObjectBuffer(d.storageKey)));

    const merged = await mergePdfs([letterBuffer, ...docBuffers]);
    const packageKey = buildStorageKey(round.dispute.clientId, "dispute_package", `round${round.roundNumber}-package.pdf`);
    await uploadBuffer(packageKey, merged, "application/pdf");

    const pkg = await prisma.disputePackage.create({
      data: {
        disputeRoundId: round.id,
        fileKey: packageKey,
      },
    });

    const actorId = (session.user as any).id;

    await logClientActivity({
      clientId: round.dispute.clientId,
      actorId,
      actorType: "user",
      description: `Round ${round.roundNumber} dispute package compiled (letter + ${documents.length} supporting document(s))`,
    });

    await writeAuditLog({
      actorId,
      action: "DISPUTE_PACKAGE_BUILT",
      entityType: "DisputePackage",
      entityId: pkg.id,
      newValue: { roundId: round.id, documentCount: documents.length },
    });

    return NextResponse.json({ package: pkg }, { status: 201 });
  } catch (err) {
    return handleError(err);
  }
}

function handleError(err: unknown) {
  if (err instanceof UnauthenticatedError) return NextResponse.json({ error: "Not authenticated" }, { status: 401 });
  if (err instanceof ForbiddenError) return NextResponse.json({ error: err.message }, { status: 403 });
  console.error(err);
  return NextResponse.json({ error: "Internal error" }, { status: 500 });
}
