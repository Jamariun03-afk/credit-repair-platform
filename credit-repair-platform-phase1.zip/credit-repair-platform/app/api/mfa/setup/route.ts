import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/db";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth/auth";
import { generateMfaSecret, encryptMfaSecret, buildProvisioningQrCode, verifyMfaCode } from "@/lib/auth/mfa";
import { writeAuditLog } from "@/lib/audit";

// GET — issues a new (not-yet-active) secret + QR code for the current user.
// Does not enable MFA until POST confirms a valid code from the authenticator app.
export async function GET() {
  const session = await getServerSession(authOptions);
  if (!session?.user) return NextResponse.json({ error: "Not authenticated" }, { status: 401 });

  const secret = generateMfaSecret();
  const qrDataUrl = await buildProvisioningQrCode((session.user as any).email, secret);

  // Store the pending (unencrypted-in-transit-only-to-this-response) secret
  // temporarily so POST can verify against it. We store it encrypted but
  // NOT marked enabled until the user proves they can generate a valid code.
  await prisma.user.update({
    where: { id: (session.user as any).id },
    data: { mfaSecret: encryptMfaSecret(secret), mfaEnabled: false },
  });

  return NextResponse.json({ qrDataUrl, secret }); // secret shown once for manual entry fallback
}

const confirmSchema = z.object({ code: z.string().length(6) });

// POST — verifies the first code and flips mfaEnabled to true.
export async function POST(req: NextRequest) {
  const session = await getServerSession(authOptions);
  if (!session?.user) return NextResponse.json({ error: "Not authenticated" }, { status: 401 });

  const body = await req.json();
  const parsed = confirmSchema.safeParse(body);
  if (!parsed.success) return NextResponse.json({ error: "Invalid code format" }, { status: 400 });

  const user = await prisma.user.findUnique({ where: { id: (session.user as any).id } });
  if (!user?.mfaSecret) return NextResponse.json({ error: "No pending MFA setup found — request a QR code first" }, { status: 400 });

  const valid = verifyMfaCode(user.mfaSecret, parsed.data.code);
  if (!valid) return NextResponse.json({ error: "Invalid code" }, { status: 400 });

  await prisma.user.update({ where: { id: user.id }, data: { mfaEnabled: true } });

  await writeAuditLog({
    actorId: user.id,
    action: "MFA_ENABLED",
    entityType: "User",
    entityId: user.id,
  });

  return NextResponse.json({ enabled: true });
}
