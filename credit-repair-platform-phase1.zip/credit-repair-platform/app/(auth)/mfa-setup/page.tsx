"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";

export default function MfaSetupPage() {
  const router = useRouter();
  const [qrDataUrl, setQrDataUrl] = useState<string | null>(null);
  const [secret, setSecret] = useState<string | null>(null);
  const [code, setCode] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [confirmed, setConfirmed] = useState(false);

  useEffect(() => {
    fetch("/api/mfa/setup")
      .then((r) => r.json())
      .then((d) => { setQrDataUrl(d.qrDataUrl); setSecret(d.secret); });
  }, []);

  async function handleConfirm(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    const res = await fetch("/api/mfa/setup", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ code }),
    });
    if (!res.ok) {
      const err = await res.json();
      setError(err.error ?? "Invalid code");
      return;
    }
    setConfirmed(true);
    setTimeout(() => router.push("/login"), 1500);
  }

  return (
    <div className="flex min-h-screen items-center justify-center bg-gray-50">
      <div className="w-full max-w-sm rounded-lg border border-gray-200 bg-white p-8 shadow-sm">
        <h1 className="mb-2 text-lg font-semibold text-gray-900">Set Up Multi-Factor Authentication</h1>
        <p className="mb-6 text-sm text-gray-500">
          Required for your role. Scan this QR code with an authenticator app (Google Authenticator, Authy, 1Password, etc.).
        </p>

        {confirmed ? (
          <p className="text-sm font-medium text-green-600">MFA enabled. Redirecting to login…</p>
        ) : (
          <>
            {qrDataUrl ? (
              <img src={qrDataUrl} alt="MFA QR code" className="mx-auto mb-4 h-40 w-40" />
            ) : (
              <p className="mb-4 text-sm text-gray-400">Generating…</p>
            )}
            {secret && (
              <p className="mb-4 break-all text-center text-xs text-gray-400">
                Can&apos;t scan? Enter manually: <span className="font-mono">{secret}</span>
              </p>
            )}
            <form onSubmit={handleConfirm}>
              <label className="mb-1 block text-sm font-medium text-gray-700">Enter the 6-digit code</label>
              <input
                type="text"
                inputMode="numeric"
                maxLength={6}
                value={code}
                onChange={(e) => setCode(e.target.value)}
                className="mb-3 w-full rounded-md border border-gray-300 px-3 py-2 text-sm tracking-widest"
              />
              {error && <p className="mb-3 text-sm text-red-600">{error}</p>}
              <button type="submit" className="w-full rounded-md bg-slate-900 py-2 text-sm font-medium text-white hover:bg-slate-800">
                Confirm & Enable
              </button>
            </form>
          </>
        )}
      </div>
    </div>
  );
}
