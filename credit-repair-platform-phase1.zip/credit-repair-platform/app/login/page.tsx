"use client";

import { useState } from "react";
import { signIn, getSession } from "next-auth/react";
import { useRouter } from "next/navigation";

export default function LoginPage() {
  const router = useRouter();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [mfaCode, setMfaCode] = useState("");
  const [needsMfaCode, setNeedsMfaCode] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    setError(null);

    const res = await signIn("credentials", {
      email,
      password,
      mfaCode: needsMfaCode ? mfaCode : undefined,
      redirect: false,
    });

    setLoading(false);

    if (res?.error === "MFA_CODE_REQUIRED") {
      setNeedsMfaCode(true);
      return;
    }
    if (res?.error === "MFA_CODE_INVALID") {
      setError("Invalid authentication code.");
      return;
    }
    if (res?.error) {
      setError("Invalid email or password.");
      return;
    }

    // Successful sign-in — check whether this is a restricted
    // mfaPending session that needs to go set up MFA first.
    const session = await getSession();
    if ((session?.user as any)?.mfaPending) {
      router.push("/mfa-setup");
      return;
    }

    router.push("/clients");
    router.refresh();
  }

  return (
    <div className="flex min-h-screen items-center justify-center bg-gray-50">
      <form onSubmit={handleSubmit} className="w-full max-w-sm rounded-lg border border-gray-200 bg-white p-8 shadow-sm">
        <h1 className="mb-6 text-lg font-semibold text-gray-900">Sign in</h1>

        <label className="mb-1 block text-sm font-medium text-gray-700">Email</label>
        <input
          type="email"
          required
          disabled={needsMfaCode}
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          className="mb-4 w-full rounded-md border border-gray-300 px-3 py-2 text-sm disabled:bg-gray-100"
        />

        <label className="mb-1 block text-sm font-medium text-gray-700">Password</label>
        <input
          type="password"
          required
          disabled={needsMfaCode}
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          className="mb-4 w-full rounded-md border border-gray-300 px-3 py-2 text-sm disabled:bg-gray-100"
        />

        {needsMfaCode && (
          <>
            <label className="mb-1 block text-sm font-medium text-gray-700">Authentication Code</label>
            <input
              type="text"
              inputMode="numeric"
              maxLength={6}
              autoFocus
              value={mfaCode}
              onChange={(e) => setMfaCode(e.target.value)}
              className="mb-4 w-full rounded-md border border-gray-300 px-3 py-2 text-sm tracking-widest"
            />
          </>
        )}

        {error && <p className="mb-4 text-sm text-red-600">{error}</p>}

        <button
          type="submit"
          disabled={loading}
          className="w-full rounded-md bg-slate-900 py-2 text-sm font-medium text-white hover:bg-slate-800 disabled:opacity-50"
        >
          {loading ? "Signing in…" : needsMfaCode ? "Verify Code" : "Sign in"}
        </button>
      </form>
    </div>
  );
}
