import { prisma } from "@/lib/db";
import { requireRole } from "@/lib/auth/rbac";

const PRIORITY_TONE: Record<string, string> = {
  URGENT: "bg-red-100 text-red-700",
  HIGH: "bg-amber-100 text-amber-700",
  NORMAL: "bg-slate-100 text-slate-600",
  LOW: "bg-gray-100 text-gray-500",
};

export default async function TasksPage() {
  const session = await requireRole(["SUPER_ADMIN", "CREDIT_SPECIALIST", "COMPLIANCE_ADMIN"]);
  const userId = (session.user as any).id;

  const tasks = await prisma.task.findMany({
    where: { assignedToId: userId, status: { not: "DONE" } },
    orderBy: [{ dueDate: "asc" }, { priority: "desc" }],
    include: { client: { select: { firstName: true, lastName: true, id: true } } },
  });

  const today = new Date();
  today.setHours(0, 0, 0, 0);

  return (
    <div className="p-8 max-w-4xl">
      <h1 className="mb-6 text-xl font-semibold text-gray-900">My Tasks</h1>

      <div className="space-y-2">
        {tasks.map((t) => {
          const overdue = t.dueDate && t.dueDate < today;
          return (
            <div key={t.id} className="flex items-center justify-between rounded-lg border border-gray-200 bg-white px-4 py-3">
              <div>
                <div className="text-sm font-medium text-gray-900">{t.title}</div>
                <div className="mt-0.5 text-xs text-gray-500">
                  {t.client && <>{t.client.firstName} {t.client.lastName} &middot; </>}
                  {t.dueDate && (
                    <span className={overdue ? "font-medium text-red-600" : ""}>
                      Due {t.dueDate.toLocaleDateString()} {overdue && "(overdue)"}
                    </span>
                  )}
                </div>
              </div>
              <span className={`rounded-full px-2.5 py-0.5 text-xs font-medium ${PRIORITY_TONE[t.priority]}`}>
                {t.priority}
              </span>
            </div>
          );
        })}
        {tasks.length === 0 && (
          <div className="rounded-lg border border-dashed border-gray-300 px-4 py-8 text-center text-sm text-gray-400">
            Nothing open on your queue.
          </div>
        )}
      </div>
    </div>
  );
}
