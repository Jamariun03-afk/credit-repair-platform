import { notFound } from "next/navigation";
import { prisma } from "@/lib/db";
import { requireClientAccess } from "@/lib/auth/rbac";
import RoundActions from "@/components/disputes/RoundActions";

export default async function RoundDetailPage({ params }: { params: { roundId: string } }) {
  const round = await prisma.disputeRound.findUnique({
    where: { id: params.roundId },
    include: {
      dispute: { include: { client: true } },
      items: { include: { negativeItem: true } },
      letters: { orderBy: { createdAt: "desc" } },
      packages: { orderBy: { createdAt: "desc" } },
      bureauResponses: { orderBy: { createdAt: "desc" } },
    },
  });

  if (!round) notFound();

  await requireClientAccess(round.dispute.clientId);

  const documents = await prisma.clientDocument.findMany({ where: { clientId: round.dispute.clientId } });

  const now = new Date();
  let deadlineTone = "text-gray-500";
  let deadlineText = "No deadline set";
  if (round.responseDeadline) {
    const daysLeft = Math.ceil((round.responseDeadline.getTime() - now.getTime()) / (1000 * 60 * 60 * 24));
    deadlineText = daysLeft >= 0 ? `Due in ${daysLeft} day(s) — ${round.responseDeadline.toLocaleDateString()}` : `Overdue by ${-daysLeft} day(s)`;
    deadlineTone = daysLeft < 0 ? "text-red-600" : daysLeft <= 7 ? "text-amber-600" : "text-gray-600";
  }

  return (
    <div className="p-8 max-w-3xl">
      <h1 className="mb-1 text-xl font-semibold text-gray-900">
        {round.dispute.client.firstName} {round.dispute.client.lastName} — {round.dispute.bureau} Round {round.roundNumber}
      </h1>
      <p className={`mb-6 text-sm ${deadlineTone}`}>
        {round.sentDate ? `Sent ${round.sentDate.toLocaleDateString()} — ${deadlineText}` : "Not yet mailed"}
      </p>

      <div className="mb-6 rounded-lg border border-gray-200 bg-white p-4">
        <h2 className="mb-2 text-sm font-semibold text-gray-800">Items in this Round</h2>
        <ul className="space-y-1 text-sm text-gray-600">
          {round.items.map((i) => (
            <li key={i.id}>
              {i.negativeItem.category.replaceAll("_", " ")} — {i.reasonType.replaceAll("_", " ")}{" "}
              <span className="text-xs text-gray-400">({i.negativeItem.status})</span>
            </li>
          ))}
        </ul>
      </div>

      {round.bureauResponses.length > 0 && (
        <div className="mb-6 rounded-lg border border-gray-200 bg-white p-4">
          <h2 className="mb-2 text-sm font-semibold text-gray-800">Bureau Responses</h2>
          {round.bureauResponses.map((r) => (
            <div key={r.id} className="text-sm text-gray-600">
              {r.responseDate.toLocaleDateString()}: {r.summary}
            </div>
          ))}
        </div>
      )}

      <RoundActions round={round} bureau={round.dispute.bureau} documents={documents} />
    </div>
  );
}
