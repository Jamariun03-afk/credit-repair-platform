import { prisma } from "@/lib/db";
import { requireRole } from "@/lib/auth/rbac";

export default async function DashboardPage() {
  await requireRole(["SUPER_ADMIN", "CREDIT_SPECIALIST", "COMPLIANCE_ADMIN"]);

  const startOfMonth = new Date();
  startOfMonth.setDate(1);
  startOfMonth.setHours(0, 0, 0, 0);

  const [
    totalActive,
    newThisMonth,
    awaitingReports,
    awaitingDocs,
    readyForAudit,
    pendingRoundStatuses,
    completed,
    negativeAgg,
  ] = await Promise.all([
    prisma.client.count({ where: { status: { notIn: ["COMPLETED", "CANCELLED"] } } }),
    prisma.client.count({ where: { enrollmentDate: { gte: startOfMonth } } }),
    prisma.client.count({ where: { status: "REPORTS_NEEDED" } }),
    prisma.client.count({ where: { status: "DOCUMENTS_NEEDED" } }),
    prisma.client.count({ where: { status: "AUDIT_PENDING" } }),
    prisma.client.count({ where: { status: { in: ["ROUND_1_PENDING", "ROUND_2_PENDING", "ROUND_3_PENDING"] } } }),
    prisma.client.count({ where: { status: "COMPLETED" } }),
    prisma.negativeItem.groupBy({ by: ["status"], _count: true }),
  ]);

  const deleted = negativeAgg.find((n) => n.status === "DELETED")?._count ?? 0;
  const corrected = negativeAgg.find((n) => n.status === "CORRECTED")?._count ?? 0;
  const totalChallenged = negativeAgg.reduce((sum, n) => sum + n._count, 0);
  const deletionRate = totalChallenged ? Math.round((deleted / totalChallenged) * 100) : 0;

  const overdueTasks = await prisma.task.count({
    where: { status: { not: "DONE" }, dueDate: { lt: new Date() } },
  });

  const unpaidPayments = await prisma.payment.findMany({
    where: { status: { in: ["UNPAID", "PARTIAL", "OVERDUE"] } },
    select: { clientId: true, amount: true },
  });
  const unpaidClientCount = new Set(unpaidPayments.map((p) => p.clientId)).size;
  const totalOutstanding = unpaidPayments.reduce((sum, p) => sum + Number(p.amount), 0);

  return (
    <div className="p-8 max-w-6xl">
      <h1 className="mb-6 text-xl font-semibold text-gray-900">Dashboard</h1>

      <div className="grid grid-cols-2 gap-4 sm:grid-cols-4">
        <Metric label="Active Clients" value={totalActive} />
        <Metric label="New This Month" value={newThisMonth} />
        <Metric label="Awaiting Reports" value={awaitingReports} tone="text-amber-600" />
        <Metric label="Awaiting Documents" value={awaitingDocs} tone="text-amber-600" />
        <Metric label="Ready for Audit" value={readyForAudit} tone="text-violet-600" />
        <Metric label="In Active Dispute Rounds" value={pendingRoundStatuses} tone="text-cyan-600" />
        <Metric label="Completed" value={completed} tone="text-green-600" />
        <Metric label="Overdue Follow-ups" value={overdueTasks} tone="text-red-600" />
        <Metric label="Clients With Unpaid Balance" value={unpaidClientCount} tone="text-amber-600" />
      </div>

      <div className="mt-4 rounded-lg border border-gray-200 bg-white p-4">
        <a href="/billing" className="text-sm text-blue-600 hover:underline">
          ${totalOutstanding.toLocaleString()} outstanding across {unpaidClientCount} client(s) — view Billing →
        </a>
      </div>

      <div className="mt-8 rounded-lg border border-gray-200 bg-white p-6">
        <h2 className="mb-4 text-sm font-semibold uppercase tracking-wide text-gray-500">
          Dispute Outcomes (All Clients, All Time)
        </h2>
        <div className="grid grid-cols-3 gap-6">
          <div>
            <div className="text-2xl font-semibold text-gray-900">{totalChallenged}</div>
            <div className="text-xs text-gray-500">Total Negative Items Challenged</div>
          </div>
          <div>
            <div className="text-2xl font-semibold text-green-600">{deleted + corrected}</div>
            <div className="text-xs text-gray-500">Deleted + Corrected</div>
          </div>
          <div>
            <div className="text-2xl font-semibold text-gray-900">{deletionRate}%</div>
            <div className="text-xs text-gray-500">Deletion Rate</div>
          </div>
        </div>
        <p className="mt-4 text-xs italic text-gray-400">
          Historical performance only — not a projection or guarantee for any individual client.
        </p>
      </div>
    </div>
  );
}

function Metric({ label, value, tone }: { label: string; value: number; tone?: string }) {
  return (
    <div className="rounded-lg border border-gray-200 bg-white p-4">
      <div className={`text-2xl font-semibold ${tone ?? "text-gray-900"}`}>{value}</div>
      <div className="mt-1 text-xs text-gray-500">{label}</div>
    </div>
  );
}
