import Link from "next/link";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth/auth";

const NAV = [
  { href: "/", label: "Dashboard" },
  { href: "/clients", label: "Clients" },
  { href: "/billing", label: "Billing" },
  { href: "/tasks", label: "Tasks" },
];

export default async function DashboardLayout({ children }: { children: React.ReactNode }) {
  const session = await getServerSession(authOptions);
  const role = (session?.user as any)?.role;

  return (
    <div className="min-h-screen">
      <nav className="border-b border-gray-200 bg-white px-6 py-3">
        <div className="mx-auto flex max-w-6xl items-center justify-between">
          <div className="flex items-center gap-6">
            <span className="text-sm font-semibold text-gray-900">Credit Repair Platform</span>
            <div className="flex gap-4">
              {NAV.map((item) => (
                <Link key={item.href} href={item.href} className="text-sm text-gray-600 hover:text-gray-900">
                  {item.label}
                </Link>
              ))}
            </div>
          </div>
          <span className="text-xs text-gray-400">{role}</span>
        </div>
      </nav>
      {children}
    </div>
  );
}
