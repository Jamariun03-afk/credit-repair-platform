import Link from "next/link";
import { prisma } from "@/lib/db";
import { requireRole } from "@/lib/auth/rbac";

const STATUS_COLORS: Record<string, string> = {
  LEAD: "bg-slate-100 text-slate-700",
  ONBOARDING: "bg-blue-100 text-blue-700",
  DOCUMENTS_NEEDED: "bg-amber-100 text-amber-700",
  REPORTS_NEEDED: "bg-amber-100 text-amber-700",
  AUDIT_PENDING: "bg-violet-100 text-violet-700",
  STRATEGY_PENDING: "bg-violet-100 text-violet-700",
  READY_FOR_ROUND_1: "bg-cyan-100 text-cyan-700",
  ROUND_1_PENDING: "bg-cyan-100 text-cyan-700",
  ROUND_2_PENDING: "bg-cyan-100 text-cyan-700",
  ROUND_3_PENDING: "bg-cyan-100 text-cyan-700",
  ESCALATION: "bg-red-100 text-red-700",
  MONITORING: "bg-teal-100 text-teal-700",
  COMPLETED: "bg-green-100 text-green-700",
  PAUSED: "bg-gray-200 text-gray-600",
  CANCELLED: "bg-gray-200 text-gray-500",
};

export default async function ClientsPage() {
  const session = await requireRole(["SUPER_ADMIN", "CREDIT_SPECIALIST", "COMPLIANCE_ADMIN"]);
  const role = (session.user as any).role;
  const userId = (session.user as any).id;

  let where: any = {};
  if (role === "CREDIT_SPECIALIST") {
    const employee = await prisma.employee.findUnique({ where: { userId } });
    where.assignedSpecialistId = employee?.id ?? "__none__";
  }

  const clients = await prisma.client.findMany({
    where,
    orderBy: { createdAt: "desc" },
    include: { assignedSpecialist: { select: { firstName: true, lastName: true } } },
  });

  return (
    <div className="p-8">
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-2xl font-semibold text-gray-900">Clients</h1>
        <Link
          href="/clients/new"
          className="rounded-md bg-slate-900 px-4 py-2 text-sm font-medium text-white hover:bg-slate-800"
        >
          + Add Client
        </Link>
      </div>

      <div className="overflow-hidden rounded-lg border border-gray-200">
        <table className="min-w-full divide-y divide-gray-200">
          <thead className="bg-gray-50">
            <tr>
              <th className="px-4 py-3 text-left text-xs font-medium uppercase tracking-wide text-gray-500">Name</th>
              <th className="px-4 py-3 text-left text-xs font-medium uppercase tracking-wide text-gray-500">Status</th>
              <th className="px-4 py-3 text-left text-xs font-medium uppercase tracking-wide text-gray-500">Specialist</th>
              <th className="px-4 py-3 text-left text-xs font-medium uppercase tracking-wide text-gray-500">Enrolled</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-100 bg-white">
            {clients.map((c) => (
              <tr key={c.id} className="hover:bg-gray-50">
                <td className="px-4 py-3 text-sm">
                  <Link href={`/clients/${c.id}`} className="font-medium text-slate-900 hover:underline">
                    {c.firstName} {c.lastName}
                  </Link>
                </td>
                <td className="px-4 py-3 text-sm">
                  <span className={`rounded-full px-2.5 py-0.5 text-xs font-medium ${STATUS_COLORS[c.status] ?? "bg-gray-100 text-gray-600"}`}>
                    {c.status.replaceAll("_", " ")}
                  </span>
                </td>
                <td className="px-4 py-3 text-sm text-gray-600">
                  {c.assignedSpecialist ? `${c.assignedSpecialist.firstName} ${c.assignedSpecialist.lastName}` : "Unassigned"}
                </td>
                <td className="px-4 py-3 text-sm text-gray-500">
                  {c.enrollmentDate.toLocaleDateString()}
                </td>
              </tr>
            ))}
            {clients.length === 0 && (
              <tr>
                <td colSpan={4} className="px-4 py-8 text-center text-sm text-gray-400">
                  No clients yet — add your first one to get started.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
