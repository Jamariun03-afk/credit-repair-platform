import { requireClientAccess } from "@/lib/auth/rbac";
import CreditReportComparison from "@/components/reports/CreditReportComparison";

export default async function ReportsPage({ params }: { params: { clientId: string } }) {
  await requireClientAccess(params.clientId);

  return (
    <div className="p-8 max-w-5xl">
      <h1 className="mb-6 text-xl font-semibold text-gray-900">Credit Reports — Bureau Comparison</h1>
      <CreditReportComparison clientId={params.clientId} />
    </div>
  );
}
