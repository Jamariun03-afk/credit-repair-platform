import { requireClientAccess } from "@/lib/auth/rbac";
import NegativeItemTracker from "@/components/negative-items/NegativeItemTracker";

export default async function NegativeItemsPage({ params }: { params: { clientId: string } }) {
  await requireClientAccess(params.clientId);

  return (
    <div className="p-8 max-w-5xl">
      <h1 className="mb-6 text-xl font-semibold text-gray-900">Negative Items</h1>
      <NegativeItemTracker clientId={params.clientId} />
    </div>
  );
}
