import { prisma } from "@/lib/db";
import { requireClientAccess } from "@/lib/auth/rbac";
import NewDisputeRoundForm from "@/components/disputes/NewDisputeRoundForm";
import Link from "next/link";

export default async function DisputesPage({ params }: { params: { clientId: string } }) {
  await requireClientAccess(params.clientId);

  const disputes = await prisma.dispute.findMany({
    where: { clientId: params.clientId },
    include: { rounds: { orderBy: { roundNumber: "asc" } } },
    orderBy: { createdAt: "desc" },
  });

  return (
    <div className="p-8 max-w-3xl">
      <h1 className="mb-6 text-xl font-semibold text-gray-900">Disputes</h1>

      <div className="mb-8 space-y-4">
        {disputes.map((d) => (
          <div key={d.id} className="rounded-lg border border-gray-200 bg-white p-4">
            <div className="mb-2 text-sm font-medium text-gray-800">{d.bureau}</div>
            <div className="flex flex-wrap gap-2">
              {d.rounds.map((r) => (
                <Link
                  key={r.id}
                  href={`/dispute-rounds/${r.id}`}
                  className="rounded-md border border-gray-200 px-3 py-1.5 text-xs text-gray-700 hover:bg-gray-50"
                >
                  Round {r.roundNumber} {r.sentDate ? "— Sent" : "— Draft"}
                </Link>
              ))}
            </div>
          </div>
        ))}
        {disputes.length === 0 && <p className="text-sm text-gray-400">No disputes started yet.</p>}
      </div>

      <h2 className="mb-3 text-sm font-semibold uppercase tracking-wide text-gray-500">New Round</h2>
      <NewDisputeRoundForm clientId={params.clientId} />
    </div>
  );
}
