import { notFound } from "next/navigation";
import { prisma } from "@/lib/db";
import { requireClientAccess } from "@/lib/auth/rbac";
import AddressPanel from "@/components/clients/AddressPanel";

export default async function ClientDetailPage({ params }: { params: { clientId: string } }) {
  await requireClientAccess(params.clientId);

  const client = await prisma.client.findUnique({
    where: { id: params.clientId },
    include: {
      assignedSpecialist: { select: { firstName: true, lastName: true } },
      activityLogs: { orderBy: { createdAt: "desc" }, take: 100 },
      creditScores: { orderBy: { snapshotDate: "desc" }, take: 3 },
      negativeItems: true,
    },
  });

  if (!client) notFound();

  const deleted = client.negativeItems.filter((i) => i.status === "DELETED").length;
  const corrected = client.negativeItems.filter((i) => i.status === "CORRECTED").length;
  const pending = client.negativeItems.filter((i) => ["SENT", "PENDING"].includes(i.status)).length;

  return (
    <div className="p-8 max-w-5xl">
      {/* Command center summary */}
      <div className="mb-8 rounded-lg border border-gray-200 bg-white p-6">
        <div className="flex items-start justify-between">
          <div>
            <h1 className="text-xl font-semibold text-gray-900">
              {client.firstName} {client.lastName}
            </h1>
            <p className="mt-1 text-sm text-gray-500">
              Status: <span className="font-medium text-gray-700">{client.status.replaceAll("_", " ")}</span>
              {client.assignedSpecialist && (
                <> &middot; Specialist: {client.assignedSpecialist.firstName} {client.assignedSpecialist.lastName}</>
              )}
            </p>
          </div>
        </div>

        <div className="mt-6 grid grid-cols-2 gap-4 sm:grid-cols-5">
          <Stat label="Original Items" value={client.negativeItems.length} />
          <Stat label="Deleted" value={deleted} tone="text-green-600" />
          <Stat label="Corrected" value={corrected} tone="text-blue-600" />
          <Stat label="Pending" value={pending} tone="text-amber-600" />
          <Stat label="Escalated" value={client.negativeItems.filter((i) => i.status === "ESCALATED").length} tone="text-red-600" />
        </div>

        {client.creditScores.length > 0 && (
          <div className="mt-6 flex gap-6 border-t border-gray-100 pt-4 text-sm">
            {client.creditScores.map((s) => (
              <div key={s.id}>
                <span className="text-gray-400">{s.bureau}</span>{" "}
                <span className="font-semibold text-gray-800">{s.score}</span>
              </div>
            ))}
          </div>
        )}
      </div>

      <div className="mb-8">
        <AddressPanel clientId={client.id} />
      </div>

      {/* Sub-navigation */}
      <div className="mb-6 flex gap-4 border-b border-gray-200 text-sm">
        <a href={`/clients/${client.id}`} className="border-b-2 border-slate-900 px-1 pb-2 font-medium text-gray-900">Overview</a>
        <a href={`/clients/${client.id}/reports`} className="px-1 pb-2 text-gray-500 hover:text-gray-800">Reports</a>
        <a href={`/clients/${client.id}/negative-items`} className="px-1 pb-2 text-gray-500 hover:text-gray-800">Negative Items</a>
        <a href={`/clients/${client.id}/disputes`} className="px-1 pb-2 text-gray-500 hover:text-gray-800">Disputes</a>
        <a href={`/clients/${client.id}/documents`} className="px-1 pb-2 text-gray-500 hover:text-gray-800">Documents</a>
        <a href={`/clients/${client.id}/billing`} className="px-1 pb-2 text-gray-500 hover:text-gray-800">Billing</a>
      </div>

      {/* Permanent timeline */}
      <div>
        <h2 className="mb-3 text-sm font-semibold uppercase tracking-wide text-gray-500">Timeline</h2>
        <div className="rounded-lg border border-gray-200 bg-white divide-y divide-gray-100">
          {client.activityLogs.length === 0 && (
            <div className="px-4 py-6 text-sm text-gray-400">No activity recorded yet.</div>
          )}
          {client.activityLogs.map((log) => (
            <div key={log.id} className="flex items-start gap-4 px-4 py-3">
              <div className="w-28 shrink-0 text-xs text-gray-400">
                {log.createdAt.toLocaleDateString()}
              </div>
              <div className="text-sm text-gray-700">
                {log.description}
                <span className="ml-2 text-xs text-gray-400">
                  ({log.actorType === "automation" ? "system" : "staff"})
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

function Stat({ label, value, tone }: { label: string; value: number; tone?: string }) {
  return (
    <div>
      <div className={`text-2xl font-semibold ${tone ?? "text-gray-900"}`}>{value}</div>
      <div className="text-xs text-gray-500">{label}</div>
    </div>
  );
}
