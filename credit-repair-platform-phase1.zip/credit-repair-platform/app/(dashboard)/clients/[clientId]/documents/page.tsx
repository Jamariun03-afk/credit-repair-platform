import { requireClientAccess } from "@/lib/auth/rbac";
import DocumentVault from "@/components/documents/DocumentVault";

export default async function ClientDocumentsPage({ params }: { params: { clientId: string } }) {
  await requireClientAccess(params.clientId);

  return (
    <div className="p-8 max-w-4xl">
      <h1 className="mb-6 text-xl font-semibold text-gray-900">Document Vault</h1>
      <DocumentVault clientId={params.clientId} />
    </div>
  );
}
