import { requireClientAccess } from "@/lib/auth/rbac";
import BillingPanel from "@/components/billing/BillingPanel";

export default async function ClientBillingPage({ params }: { params: { clientId: string } }) {
  await requireClientAccess(params.clientId);

  return (
    <div className="p-8 max-w-3xl">
      <h1 className="mb-6 text-xl font-semibold text-gray-900">Billing</h1>
      <BillingPanel clientId={params.clientId} />
    </div>
  );
}
