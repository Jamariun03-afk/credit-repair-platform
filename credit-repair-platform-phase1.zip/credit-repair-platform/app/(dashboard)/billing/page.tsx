import Link from "next/link";
import { prisma } from "@/lib/db";
import { requireRole } from "@/lib/auth/rbac";

export default async function BillingPage() {
  const session = await requireRole(["SUPER_ADMIN", "CREDIT_SPECIALIST", "COMPLIANCE_ADMIN"]);
  const role = (session.user as any).role;
  const userId = (session.user as any).id;

  let clientWhere: any = {};
  if (role === "CREDIT_SPECIALIST") {
    const employee = await prisma.employee.findUnique({ where: { userId } });
    clientWhere.assignedSpecialistId = employee?.id ?? "__none__";
  }

  const clients = await prisma.client.findMany({
    where: clientWhere,
    include: { payments: { orderBy: { dueDate: "desc" } } },
    orderBy: { lastName: "asc" },
  });

  const now = new Date();

  const rows = clients.map((c) => {
    const outstanding = c.payments.filter((p) => ["UNPAID", "PARTIAL", "OVERDUE"].includes(p.status));
    const overdue = outstanding.filter((p) => p.dueDate && p.dueDate < now);
    const totalOwed = outstanding.reduce((sum, p) => sum + Number(p.amount), 0);
    const totalPaid = c.payments.filter((p) => p.status === "PAID").reduce((sum, p) => sum + Number(p.amount), 0);
    const mostRecent = c.payments[0];

    let overallStatus: "current" | "unpaid" | "overdue" | "no-charges" = "no-charges";
    if (overdue.length > 0) overallStatus = "overdue";
    else if (outstanding.length > 0) overallStatus = "unpaid";
    else if (c.payments.length > 0) overallStatus = "current";

    return { client: c, totalOwed, totalPaid, overdue: overdue.length, mostRecent, overallStatus };
  });

  const totalOutstanding = rows.reduce((sum, r) => sum + r.totalOwed, 0);
  const overdueCount = rows.filter((r) => r.overallStatus === "overdue").length;
  const unpaidCount = rows.filter((r) => r.overallStatus === "unpaid" || r.overallStatus === "overdue").length;

  const STATUS_BADGE: Record<string, string> = {
    current: "bg-green-100 text-green-700",
    unpaid: "bg-amber-100 text-amber-700",
    overdue: "bg-red-100 text-red-700",
    "no-charges": "bg-gray-100 text-gray-500",
  };
  const STATUS_LABEL: Record<string, string> = {
    current: "Paid Up",
    unpaid: "Payment Due",
    overdue: "Overdue",
    "no-charges": "No Charges Yet",
  };

  return (
    <div className="p-8 max-w-5xl">
      <h1 className="mb-1 text-xl font-semibold text-gray-900">Billing</h1>
      <p className="mb-6 text-sm text-gray-500">Who's paid, who owes, and who's overdue — across every client.</p>

      <div className="mb-6 grid grid-cols-3 gap-4">
        <div className="rounded-lg border border-gray-200 bg-white p-4">
          <div className="text-2xl font-semibold text-gray-900">${totalOutstanding.toLocaleString()}</div>
          <div className="text-xs text-gray-500">Total Outstanding</div>
        </div>
        <div className="rounded-lg border border-gray-200 bg-white p-4">
          <div className="text-2xl font-semibold text-amber-600">{unpaidCount}</div>
          <div className="text-xs text-gray-500">Clients With Unpaid Balance</div>
        </div>
        <div className="rounded-lg border border-gray-200 bg-white p-4">
          <div className="text-2xl font-semibold text-red-600">{overdueCount}</div>
          <div className="text-xs text-gray-500">Clients Overdue</div>
        </div>
      </div>

      <div className="overflow-hidden rounded-lg border border-gray-200 bg-white">
        <table className="min-w-full divide-y divide-gray-200">
          <thead className="bg-gray-50">
            <tr>
              <th className="px-4 py-2 text-left text-xs font-medium uppercase text-gray-500">Client</th>
              <th className="px-4 py-2 text-left text-xs font-medium uppercase text-gray-500">Status</th>
              <th className="px-4 py-2 text-left text-xs font-medium uppercase text-gray-500">Owed</th>
              <th className="px-4 py-2 text-left text-xs font-medium uppercase text-gray-500">Paid to Date</th>
              <th className="px-4 py-2 text-left text-xs font-medium uppercase text-gray-500">Last Payment</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-100">
            {rows.map((r) => (
              <tr key={r.client.id} className="hover:bg-gray-50">
                <td className="px-4 py-3 text-sm">
                  <Link href={`/clients/${r.client.id}/billing`} className="font-medium text-slate-900 hover:underline">
                    {r.client.firstName} {r.client.lastName}
                  </Link>
                </td>
                <td className="px-4 py-3 text-sm">
                  <span className={`rounded-full px-2.5 py-0.5 text-xs font-medium ${STATUS_BADGE[r.overallStatus]}`}>
                    {STATUS_LABEL[r.overallStatus]}
                  </span>
                </td>
                <td className="px-4 py-3 text-sm text-gray-700">{r.totalOwed > 0 ? `$${r.totalOwed.toLocaleString()}` : "—"}</td>
                <td className="px-4 py-3 text-sm text-gray-500">${r.totalPaid.toLocaleString()}</td>
                <td className="px-4 py-3 text-sm text-gray-500">
                  {r.mostRecent?.paidDate ? new Date(r.mostRecent.paidDate).toLocaleDateString() : "—"}
                </td>
              </tr>
            ))}
            {rows.length === 0 && (
              <tr><td colSpan={5} className="px-4 py-8 text-center text-sm text-gray-400">No clients yet.</td></tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
